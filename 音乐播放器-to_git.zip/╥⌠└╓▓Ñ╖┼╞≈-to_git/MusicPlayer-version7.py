import tkinter.filedialog
from tkinter import colorchooser
from tkinter import*
from pygame import mixer
import time
import os
import threading
from mutagen.mp3 import MP3
from mutagen.flac import FLAC

all_files=os.listdir(os.curdir+'\\音乐文件')#当前目录中的文件名用列表存储
p=True
play_list=[]# 加入播放序列
bool_play_list=True# 播放序列是否开启
loop=0# 循环播放
process=True# 让进度条线程死掉
def list_of_play():
    play_list.append(lb.get(ACTIVE))
    text.insert(END,'已将%s添加至播放序列\n'%lb.get(ACTIVE))
def list_of_show():
    top=Toplevel()
    top.geometry('26x17+500+200')
    top.title('播放序列')
    sb2=Scrollbar(top,orient=HORIZONTAL)
    sb2.pack(side=BOTTOM,fill=X)
    sb=Scrollbar(top)    
    lb=Listbox(top,width=30,height=13,setgrid=True,fg='black',bg='#ffff80',font=('黑体',10),cursor='heart',xscrollcommand=sb2.set,yscrollcommand=sb.set)
    lb.pack(side=LEFT,fill=BOTH)
    sb.pack(side='left',fill=Y)
    for i in play_list:
        lb.insert(END,i)
    sb.config(command=lb.yview)
    sb2.config(command=lb.xview)
    def delete_it():
        play_list.remove(lb.get(ACTIVE))
        top.destroy()
        list_of_show()
    def delete_them():
        play_list.clear()
        top.destroy()
        list_of_show()
    Button(top,text='删除',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=delete_it).pack(side='left',padx=10,pady=10)
    menubar=Menu(top)
    menubar.add_command(label='全部删除',command=delete_them)
    top.config(menu=menubar)
def play_the_list():
    global process#
    mixer.init()
    text.insert(END,'播放序列开启成功\n')
    while bool_play_list:
        if mixer.music.get_busy()==False and len(play_list)!=0:
            mixer.init()
            mixer.music.load('音乐文件\\'+play_list[0])
            mixer.music.set_volume(s2.get())    
            mixer.music.play()
            get_mp3_length('音乐文件\\'+play_list[0])
            process=True#
            now()
            del play_list[0]
    text.insert(END,'播放序列成功关闭\n')
def open_list():
    global bool_play_list
    bool_play_list=True
    t=threading.Thread(target=play_the_list)
    t.start()
def close_list():
    global bool_play_list
    bool_play_list=False
def stop():
    mixer.music.stop()
#设置循环播放
def open_loop():
    global loop
    loop=-1
def close_loop():
    global loop
    loop=0
# 设置进度条
def clear_process():
    global process#
    process=False#
def get_mp3_length(file):
    temp=file.split('.')
    if temp[len(temp)-1]=='mp3' or temp[len(temp)-1]=='MP3':
        audio = MP3(file)
        s1['tickinterval']=audio.info.length
        s1['to']=audio.info.length
    elif temp[len(temp)-1]=='flac' or temp[len(temp)-1]=='FLAC':
        audio = FLAC(file)
        s1['tickinterval']=audio.info.length
        s1['to']=audio.info.length
def set_time():
    while process:
        time.sleep(0.9)
        s1.set(mixer.music.get_pos()/1000)
def now():
    t=threading.Thread(target=set_time)
    t.start()
#-----------
def play():
    global bool_play_list
    global process#
    bool_play_list=False
    mixer.init()
    temp=lb.get(ACTIVE)
    mixer.music.load('音乐文件\\'+temp)
    mixer.music.set_volume(s2.get())    
    mixer.music.play(loop)
    get_mp3_length('音乐文件\\'+temp)
    process=True#
    now()
    if loop==-1:
        text.insert(END,'此歌曲循环播放\n')
    if loop==0:
        text.insert(END,'此歌曲单曲播放\n')
    #time.sleep(1)
    #mixer.music.stop()
def rewind():
    mixer.music.rewind()
def pause():
    global p
    if p:
        mixer.music.pause()
        p=not p
    else:
        mixer.music.unpause()
        p=not p
def callback(event):
    mixer.music.set_volume(s2.get())
    
def gettime():
    text.insert(END,'播放时长：%ss\n'% str(mixer.music.get_pos()/1000))
def settime():
    top=Toplevel()
    top.title('进度')
    Label(top,text='对于 OGG 文件，它是一个以音频开头为零点的绝对时间值（以秒为单位）').pack()
    Label(top,text='对于 MP3 文件，它是以当前播放位置为零点的绝对时间值（以秒为单位）').pack()
    e=Entry(top)
    e.pack(padx=10,pady=10)
    def sets():
        s=e.get()
        mixer.music.set_pos(int(s))
    Button(top,text='确定',bg='yellow',command=sets).pack(padx=10,pady=10)
def clear():
    text.delete('1.0','end')
def file_music():
    global process
    filename=filedialog.askopenfilename(filetypes=[('MP3','.mp3'),('wav','.wav'),('flac','.flac'),('MP4','.mp4'),('OGG','.ogg')])
    if filename:
        mixer.init()
        mixer.music.load(filename)
        mixer.music.set_volume(s2.get())
        mixer.music.play(loop)
        get_mp3_length(filename)
        process=True#
        now()
def color1():
    fileName = colorchooser.askcolor()
    if fileName[1]:
        frame['background']=fileName[1]
def color2():
    fileName = colorchooser.askcolor()
    if fileName[1]:
        text['background']=fileName[1]
def color3():
    fileName = colorchooser.askcolor()
    if fileName[1]:
        lb['background']=fileName[1]
        
root=Tk()
#设置窗口图标
root.iconbitmap('素材.ico')
root.attributes('-toolwindow', False, 
                '-alpha', 1, 
                '-fullscreen',False, 
                '-topmost', False)
#root.overrideredirect(True)  #去掉标题栏
root.title('音乐')
frame=Frame(root,width=600,height=400,bg='pink')
frame.pack(fill=BOTH,expand=True,padx=10,pady=10,ipadx=10,ipady=10)
#---Listbox
sb2=Scrollbar(frame,orient=HORIZONTAL)
sb2.pack(side=BOTTOM,fill=X)
sb=Scrollbar(frame)
sb.pack(side=RIGHT,fill=Y)
lb=Listbox(frame,width=40,height=12,setgrid=True,bg='#ffff80',font=('黑体',10),cursor='heart',xscrollcommand=sb2.set,yscrollcommand=sb.set)
lb.pack(side=RIGHT,fill=BOTH)
for i in all_files:
    lb.insert(END,i)
sb.config(command=lb.yview)
sb2.config(command=lb.xview)
#-------------给Text加滚动条
sb1=Scrollbar(frame)
sb1.pack(side=RIGHT,fill=Y)
text=Text(frame,width=25,height=12,fg='black',bg='#34de21',yscrollcommand=sb1.set)
text.pack(side=RIGHT,fill=Y)
sb1.config(command=text.yview)
#-----
Button(frame,text='播放',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=play).pack(padx=10,pady=10)
Button(frame,text='重播',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=rewind).pack(padx=10,pady=10)
Button(frame,text='暂停\\续播',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=pause).pack(padx=10,pady=10)
Button(frame,text='添加到序列',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=list_of_play).pack(padx=10,pady=10)
Button(frame,text='停止\\下一首',cursor='target',fg='black',bg='white',font='华文琥珀',width=10,command=stop).pack(padx=10,pady=10)
# 下框架
frame1=Frame(root,bg='white')
frame1.pack(fill=BOTH,expand=True)
# 进度条
Label(frame1,text='进度',fg='black',bg='ghostwhite').grid(row=0,column=0)
s1=Scale(frame1,from_=0,to=300,orient=HORIZONTAL,cursor='fleur',
         tickinterval=300,resolution=1,length=700)#刻度，精度，长度
#s1.set(0.3)
s1.grid(row=0,column=1)
#---音量
Label(frame1,text='音量',fg='black',bg='ghostwhite').grid(row=1,column=0)
s2=Scale(frame1,from_=0,to=1,orient=HORIZONTAL,cursor='fleur',
         tickinterval=0.05,resolution=0.05,length=700)#刻度，精度，长度
s2.set(0.3)
s2.grid(row=1,column=1)
#---绑定鼠标
s2.bind("<Button-1>",callback)
#-----------------菜单
menubar=Menu(root)
#menubar.add_command(label='添加播放队列',command=playqueue)
menubar.add_command(label='获取播放时长',command=gettime)
menubar.add_command(label='设置播放位置',command=settime)
menubar.add_command(label='清空Text',command=clear)
menubar.add_command(label='找音乐',command=file_music)
#级联菜单
filemenu2=Menu(menubar,tearoff=False)
filemenu2.add_command(label='开启',command=open_loop)
filemenu2.add_command(label='关闭',command=close_loop)
menubar.add_cascade(label='循环播放',menu=filemenu2)
#.......

#级联菜单
filemenu1=Menu(menubar,tearoff=False)
filemenu1.add_command(label='开启播放序列',command=open_list)
filemenu1.add_command(label='关闭播放序列',command=close_list)
filemenu1.add_command(label='添加播放序列',command=list_of_play)
filemenu1.add_command(label='显示播放序列',command=list_of_show)
menubar.add_cascade(label='播放序列',menu=filemenu1)
#.......

#级联菜单
filemenu=Menu(menubar,tearoff=False)
filemenu.add_command(label='按钮区',command=color1)
filemenu.add_command(label='信息区',command=color2)
filemenu.add_command(label='歌单区',command=color3)
menubar.add_cascade(label='背景色',menu=filemenu)
#.......
menubar.add_command(label='清理进度条线程',command=clear_process)
root.config(menu=menubar)#把menubar放进root中
#-----------------
mainloop()

